from flask import Flask, render_template, request, url_for, redirect
import os
import sqlite3

app = Flask(__name__)

# -----------------------------
# DB CONNECTION
# -----------------------------
def get_db_connection():
    conn = sqlite3.connect('hotel.db')
    conn.row_factory = sqlite3.Row
    return conn

def run_query(sql):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    conn.close()
    return rows

QUERY_FACILITY_USAGE = """
SELECT
    f.facilityName,
    COUNT(*) AS total_visits,
    COUNT(DISTINCT al.customerId) AS unique_customers
FROM access_log al
JOIN facility f
     ON al.facilityId = f.facilityId
GROUP BY f.facilityName
ORDER BY total_visits DESC;
"""

QUERY_STAFF_WORKLOAD = """
SELECT
    s.staffId,
    s.name AS staff_name,
    s.staffPosition,
    COUNT(DISTINCT ra.assignmentId) AS room_assignments_handled,
    COUNT(DISTINCT gm.messageId)    AS messages_handled
FROM staff s
LEFT JOIN room_assignment ra
       ON ra.staffId = s.staffId
LEFT JOIN guest_message gm
       ON gm.staffId = s.staffId
GROUP BY s.staffId, s.name, s.staffPosition
ORDER BY room_assignments_handled DESC, messages_handled DESC;
"""

QUERY_TOP_REVENUE = """
SELECT
    f.facilityName,
    s.serviceType,
    SUM(sc.chargeAmount * (1 - sc.discountRate)) AS total_service_revenue,
    COUNT(sc.chargeId) AS number_of_charges
FROM transmittal_transaction tt
JOIN service_charge sc
     ON tt.chargeId = sc.chargeId
JOIN service s
     ON sc.serviceId = s.serviceId
LEFT JOIN facility f
       ON s.facilityId = f.facilityId
GROUP BY f.facilityName, s.serviceType
ORDER BY total_service_revenue DESC
LIMIT 5;
"""

QUERY_ROOM_TYPE_USAGE = """
SELECT
    rt.roomTypeName,
    COUNT(ra.assignmentId) AS number_of_assignments,
    COUNT(DISTINCT ra.roomId) AS distinct_rooms_used,
    COUNT(DISTINCT ra.reservationId) AS distinct_reservations
FROM room_assignment ra
JOIN room r
     ON ra.roomId = r.roomId
JOIN room_type rt
     ON r.roomTypeId = rt.roomTypeId
GROUP BY rt.roomTypeName
ORDER BY number_of_assignments DESC;
"""

QUERY_EVENT_ATTENDANCE = """
SELECT
    o.organizationId,
    o.organizationName,
    COUNT(e.eventId) AS number_of_events,
    SUM(e.expectedAttendance) AS total_expected_attendance
FROM event e
LEFT JOIN organization o
       ON e.organizationId = o.organizationId
GROUP BY o.organizationId, o.organizationName
ORDER BY number_of_events DESC;
"""

QUERY_TODAY_ARRIVALS = """
SELECT
    r.reservationId,
    c.name AS customer_name,
    r.checkIn,
    r.checkOut,
    r.numGuests,
    rt.roomTypeName,
    r.bookingSource
FROM reservation r
JOIN customer c
     ON r.customerId = c.customerId
JOIN room_type rt
     ON r.roomTypeId = rt.roomTypeId
JOIN room_assignment ra
     ON ra.reservationId = r.reservationId
JOIN room rm
     ON rm.roomId = ra.roomId
WHERE r.checkIn = '2025-01-15'
ORDER BY c.name;
"""

QUERY_OCCUPIED_ROOMS = """
SELECT
    rm.roomId,
    rm.roomNumber,
    r.reservationId,
    c.name AS customer_name
FROM room_assignment ra
JOIN room rm
     ON ra.roomId = rm.roomId
JOIN reservation r
     ON ra.reservationId = r.reservationId
JOIN customer c
     ON r.customerId = c.customerId
WHERE ra.startDate <= '2025-01-15'
  AND ra.endDate   >  '2025-01-15'
ORDER BY rm.roomNumber;
"""

QUERY_PENDING_CALLBACKS = """
SELECT
    gm.messageId,
    gm.timestamp,
    gm.messageType,
    gm.messageContent,
    c.name AS customer_name,
    rm.roomNumber,
    gm.status
FROM guest_message gm
JOIN customer c
     ON gm.customerId = c.customerId
LEFT JOIN room rm
       ON gm.roomId = rm.roomId
WHERE gm.status = 'Active'
  AND gm.isCallbackRequested = 1
ORDER BY gm.timestamp;
"""

# -------------------------------------------
# Keyword → SQL mapping
# -------------------------------------------

KEYWORD_MAP = {
    # Query 1: Facility usage
    "facility usage": QUERY_FACILITY_USAGE,
    "facility visits": QUERY_FACILITY_USAGE,
    "popular facility": QUERY_FACILITY_USAGE,
    "facility traffic": QUERY_FACILITY_USAGE,

    # Query 2: Staff workload
    "staff workload": QUERY_STAFF_WORKLOAD,
    "staff work": QUERY_STAFF_WORKLOAD,
    "which staff busy": QUERY_STAFF_WORKLOAD,
    "workload": QUERY_STAFF_WORKLOAD,

    # Query 3: Top revenue
    "top revenue": QUERY_TOP_REVENUE,
    "highest revenue": QUERY_TOP_REVENUE,
    "service revenue": QUERY_TOP_REVENUE,
    "facility revenue": QUERY_TOP_REVENUE,

    # Query 4: Room-type usage
    "room type usage": QUERY_ROOM_TYPE_USAGE,
    "room utilization": QUERY_ROOM_TYPE_USAGE,
    "room demand": QUERY_ROOM_TYPE_USAGE,

    # Query 5: Event attendance
    "event attendance": QUERY_EVENT_ATTENDANCE,
    "events": QUERY_EVENT_ATTENDANCE,
    "organization events": QUERY_EVENT_ATTENDANCE,

    # Query 6: Arrivals today
    "today arrivals": QUERY_TODAY_ARRIVALS,
    "arrivals": QUERY_TODAY_ARRIVALS,
    "check-in list": QUERY_TODAY_ARRIVALS,

    # Query 7: Occupied rooms
    "occupied rooms": QUERY_OCCUPIED_ROOMS,
    "rooms occupied": QUERY_OCCUPIED_ROOMS,
    "in-house guests": QUERY_OCCUPIED_ROOMS,

    # Query 8: Pending callbacks
    "pending callbacks": QUERY_PENDING_CALLBACKS,
    "callback": QUERY_PENDING_CALLBACKS,
    "follow-up": QUERY_PENDING_CALLBACKS,
}

# Routes For Search
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/search", methods=["POST"])
def search():
    keyword = request.form.get("search", "").lower()

    for key in KEYWORD_MAP:
        if key in keyword:
            sql = KEYWORD_MAP[key]
            results = run_query(sql)

            return render_template(
                "index.html",
                keyword=key,
                rows=results,
                sql=sql
            )

    # If no keyword matched
    return render_template(
        "index.html",
        keyword=keyword,
        rows=[],
        sql="No matching query found."
    )


# Route For Update
@app.route("/update_page")
def update_page():
    return render_template("update.html")

@app.route("/search_message", methods=["POST"])
def search_message():
    customer_name = request.form["customer_name"]
    timestamp = request.form['timestamp']

    timestamp = timestamp.replace("T", " ") + ":00"

    conn = get_db_connection()
    result = conn.execute("""
        SELECT gm.*
        FROM guest_message gm
        JOIN customer c ON gm.customerId = c.customerId
        WHERE c.name LIKE ? 
          AND gm.timestamp = ?
    """, (customer_name, timestamp)).fetchall()

    conn.close()

    return render_template("update.html", result=result)

@app.route("/update_status", methods=["POST"])
def update_status():
    message_id = request.form['messageId']
    new_status = request.form['new_status']

    conn = get_db_connection()
    conn.execute(
        "UPDATE guest_message SET status = ? WHERE messageId = ?",
        (new_status, message_id)
    )
    conn.commit()
    conn.close()

    return redirect("/update_page")
 

 
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)



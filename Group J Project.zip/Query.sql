-- 1) Facility usage volume 
SELECT
    f.facilityName,
    COUNT(*) AS total_visits,
    COUNT(DISTINCT al.customerId) AS unique_customers
FROM access_log al
JOIN facility f
     ON al.facilityId = f.facilityId
GROUP BY f.facilityName
ORDER BY total_visits DESC;

-- 2) Staff workload
SELECT
    s.staffId,
    s.name AS staff_name,
    s.staffPosition,
    COUNT(DISTINCT ra.assignmentId) AS room_assignments_handled,
    COUNT(DISTINCT gm.messageId)    AS messages_handled
FROM staff s
LEFT JOIN room_assignment ra
       ON ra.staffId = s.staffId
LEFT JOIN guest_message gm
       ON gm.staffId = s.staffId
GROUP BY s.staffId, s.name, s.staffPosition
ORDER BY room_assignments_handled DESC, messages_handled DESC;

-- 3) Revenue by service type and facility
SELECT
    f.facilityName,
    s.serviceType,
    SUM(sc.chargeAmount * (1 - sc.discountRate)) AS total_service_revenue,
    COUNT(sc.chargeId) AS number_of_charges
FROM transmittal_transaction tt
JOIN service_charge sc
     ON tt.chargeId = sc.chargeId
JOIN service s
     ON sc.serviceId = s.serviceId
LEFT JOIN facility f
       ON s.facilityId = f.facilityId
GROUP BY f.facilityName, s.serviceType
ORDER BY total_service_revenue DESC
LIMIT 5;

--4) Reservation for guests sleeping in the hotel
SELECT
    rt.roomTypeName,
    COUNT(ra.assignmentId) AS number_of_assignments,
    COUNT(DISTINCT ra.roomId) AS distinct_rooms_used,
    COUNT(DISTINCT ra.reservationId) AS distinct_reservations
FROM room_assignment ra
JOIN room r
     ON ra.roomId = r.roomId
JOIN room_type rt
     ON r.roomTypeId = rt.roomTypeId
GROUP BY rt.roomTypeName
ORDER BY number_of_assignments DESC;

-- 5) Events and expected attendance per organization
SELECT
    o.organizationId,
    o.organizationName,
    COUNT(e.eventId) AS number_of_events,
    SUM(e.expectedAttendance) AS total_expected_attendance,
FROM event e
LEFT JOIN organization o
       ON e.organizationId = o.organizationId
GROUP BY o.organizationId, o.organizationName
ORDER BY number_of_events DESC;

-- 6)Today's arrivals
SELECT
    r.reservationId,
    c.name AS customer_name,
    r.checkIn,
    r.checkOut,
    r.numGuests,
    rt.roomTypeName,
    rm.roomNumber,
    r.bookingSource
FROM reservation r
JOIN customer c
     ON r.customerId = c.customerId
JOIN room_type rt
     ON r.roomTypeId = rt.roomTypeId
JOIN room_assignment ra
     ON ra.reservationId = r.reservationId
JOIN room rm
     ON rm.roomId = ra.roomId
WHERE r.checkIn = '2025-01-15'
ORDER BY c.name;

-- 7) Rooms occupied on a specific date
SELECT
    rm.roomId,
    rm.roomNumber,
    r.reservationId,
    c.name AS customer_name
FROM room_assignment ra
JOIN room rm
     ON ra.roomId = rm.roomId
JOIN reservation r
     ON ra.reservationId = r.reservationId
JOIN customer c
     ON r.customerId = c.customerId
WHERE ra.startDate <= '2025-01-15'
  AND ra.endDate   >  '2025-01-15'
ORDER BY rm.roomNumber;

-- 8) Guest messages with callback requested and not completed
SELECT
    gm.messageId,
    gm.timestamp,
    gm.messageType,
    gm.messageContent,
    c.name AS customer_name,
    rm.roomNumber,
    gm.status
FROM guest_message gm
JOIN customer c
     ON gm.customerId = c.customerId
LEFT JOIN room rm
       ON gm.roomId = rm.roomId
WHERE gm.status = 'Active'
     AND gm.isCallbackRequested = 1
ORDER BY gm.timestamp;

--9）Update Guest Message Status
--Search correspond message
SELECT gm.*
        FROM guest_message gm
        JOIN customer c ON gm.customerId = c.customerId
        WHERE c.name LIKE ? 
          AND gm.timestamp = ?

--Update data status
UPDATE guest_message SET status = ? WHERE messageId = ?


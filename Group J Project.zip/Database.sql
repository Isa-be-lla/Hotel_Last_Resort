PRAGMA foreign_keys = ON;


CREATE TABLE building (
    buildingId      INTEGER PRIMARY KEY,
    buildingName    TEXT NOT NULL,
    numOfFloor      INTEGER
);

CREATE TABLE wing (
    wingId              INTEGER PRIMARY KEY,
    buildingId          INTEGER NOT NULL,
    wingName            TEXT NOT NULL,
    isSmoking           INTEGER DEFAULT 0,      
    handicapAccess      INTEGER DEFAULT 0,
    proximityPool       TEXT,                 
    proximityParking    TEXT,                
    FOREIGN KEY (buildingId) REFERENCES building(buildingId)
);

CREATE TABLE floor (
    floorId     INTEGER PRIMARY KEY,
    buildingId  INTEGER NOT NULL,
    wingId      INTEGER NOT NULL,
    floorNumber INTEGER NOT NULL,
    isSmoking   INTEGER DEFAULT 0,
    FOREIGN KEY (buildingId) REFERENCES building(buildingId),
    FOREIGN KEY (wingId)     REFERENCES wing(wingId)
);

CREATE TABLE room_type (
    roomTypeId      INTEGER PRIMARY KEY,
    roomTypeName    TEXT NOT NULL           
);

CREATE TABLE bed_type (
    bedTypeId   INTEGER PRIMARY KEY,             
    name        TEXT NOT NULL                
);

CREATE TABLE facility (
    facilityId      INTEGER PRIMARY KEY,
    facilityName    TEXT NOT NULL         
);

CREATE TABLE service (
    serviceId           INTEGER PRIMARY Key,
    facilityId          INTEGER,
    serviceType         TEXT NOT NULL,
    serviceDescription  TEXT,
    FOREIGN KEY (facilityId) REFERENCES facility(facilityId)
);

CREATE TABLE customer_type (
    customerTypeId  INTEGER PRIMARY KEY,
    typeName        TEXT NOT NULL,
    isHost          INTEGER DEFAULT 0         
);

CREATE TABLE organization (
    organizationId  INTEGER PRIMARY KEY,
    organizationName    TEXT NOT NULL,
    payerName       TEXT,
    phone           TEXT,
    address         TEXT
);

CREATE TABLE staff (
    staffId     INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    staffPosition    TEXT
);


CREATE TABLE room (
    roomId              INTEGER PRIMARY KEY,      
    roomTypeId          INTEGER NOT NULL,
    wingId              INTEGER NOT NULL,
    floorId             INTEGER NOT NULL,
    roomNumber          TEXT NOT NULL,        
    status              TEXT,                 
    capacity            INTEGER,             
    rating              REAL,                  
    isSmoking           INTEGER DEFAULT 0,
    FOREIGN KEY (roomTypeId) REFERENCES room_type(roomTypeId),
    FOREIGN KEY (wingId)     REFERENCES wing(wingId),
    FOREIGN KEY (floorId)    REFERENCES floor(floorId)
);

CREATE TABLE room_bed_assignment (
    roomId      INTEGER,
    bedTypeId   INTEGER,
    quantity    INTEGER NOT NULL,
    PRIMARY KEY (roomId, bedTypeId),
    FOREIGN KEY (roomId)    REFERENCES room(roomId),
    FOREIGN KEY (bedTypeId) REFERENCES bed_type(bedTypeId)
);

CREATE TABLE room_adjacency (
    roomId1         INTEGER,
    roomId2         INTEGER,
    adjacencyType   TEXT,              
    accessType      TEXT,              
    hasMovableWall  INTEGER DEFAULT 0,
    PRIMARY KEY (roomId1, roomId2),
    FOREIGN KEY (roomId1) REFERENCES room(roomId),
    FOREIGN KEY (roomId2) REFERENCES room(roomId)
);

CREATE TABLE sleeping_room_detail (
    sleepingRoomId      INTEGER PRIMARY KEY,
    roomId              INTEGER NOT NULL,
    hasExtraSpace       INTEGER DEFAULT 0,
    maxOccupancy        INTEGER,
    canBeMeetingRoom    INTEGER DEFAULT 0,
    FOREIGN KEY (roomId) REFERENCES room(roomId)
);

CREATE TABLE meeting_room_detail (
    meetingRoomId       INTEGER PRIMARY KEY,
    roomId              INTEGER NOT NULL,
    isOutdoor           INTEGER DEFAULT 0,
    canBeSleepingRoom   INTEGER DEFAULT 0,
    FOREIGN KEY (roomId) REFERENCES room(roomId)
);

CREATE TABLE sleeping_room_cost (
    sleepingRoomCostId  INTEGER PRIMARY KEY,
    sleepingRoomId      INTEGER NOT NULL,
    baseRate            REAL NOT NULL,
    extensionType       TEXT,        
    longerExtensionHour INTEGER,     
    surchargeAmount     REAL,
    effectiveDate       DATE,
    FOREIGN KEY (sleepingRoomId) REFERENCES sleeping_room_detail(sleepingRoomId)
);


CREATE TABLE customer (
    customerId      INTEGER PRIMARY KEY,
    name            TEXT NOT NULL,
    organizationId  INTEGER,
    customerTypeId  INTEGER NOT NULL,
    email           TEXT NOT NULL,
    phoneNumber     TEXT NOT NULL,
    FOREIGN KEY (organizationId) REFERENCES organization(organizationId),
    FOREIGN KEY (customerTypeId) REFERENCES customer_type(customerTypeId)
);

CREATE TABLE card (
    cardId      INTEGER PRIMARY KEY,
    PIN         TEXT NOT NULL,
    customerId  INTEGER,       
    staffId     INTEGER,       
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (staffId)     REFERENCES staff(staffId)
);

CREATE TABLE access_log (
    accessId    INTEGER PRIMARY KEY,
    cardId      INTEGER,
    buildingId  INTEGER,
    wingId      INTEGER,
    roomId      INTEGER,
    facilityId  INTEGER,
    customerId  INTEGER,
    staffId     INTEGER,
    enterTime   DATETIME,
    leavingTime DATETIME,
    FOREIGN KEY (cardId)     REFERENCES card(cardId),
    FOREIGN KEY (buildingId) REFERENCES building(buildingId),
    FOREIGN KEY (wingId)     REFERENCES wing(wingId),
    FOREIGN KEY (roomId)     REFERENCES room(roomId),
    FOREIGN KEY (facilityId) REFERENCES facility(facilityId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (staffId)    REFERENCES staff(staffId)
);

CREATE TABLE guest_message (
    messageId           INTEGER PRIMARY KEY,
    customerId          INTEGER NOT NULL,
    roomId              INTEGER,
    messageType         TEXT,         
    timestamp           DATETIME,
    privacySetting      TEXT,       
    isCallbackRequested INTEGER DEFAULT 0,
    staffId             INTEGER,
    status              TEXT,         
    messageContent      TEXT,
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (roomId)     REFERENCES room(roomId),
    FOREIGN KEY (staffId)    REFERENCES staff(staffId)
);


CREATE TABLE reservation (
    reservationId   INTEGER PRIMARY KEY,
    customerId      INTEGER NOT NULL,
    checkIn         DATE NOT NULL,
    checkOut        DATE NOT NULL,
    numGuests       INTEGER NOT NULL,
    bedTypeId       INTEGER NOT NULL,
    smokingPreference   TEXT NOT NULL,
    depositAmount   REAL NOT NULL,
    status          TEXT NOT NULL,         
    bookingSource   TEXT NOT NULL,         
    createdAt       DATETIME,
    roomTypeId        Integer NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (bedTypeId)  REFERENCES bed_type(bedTypeId),
    FOREIGN KEY (roomTypeId)  REFERENCES room_type(roomTypeId)
);

CREATE TABLE room_assignment (
    assignmentId    INTEGER PRIMARY KEY,
    reservationId   INTEGER NOT NULL,
    roomId          INTEGER NOT NULL,
    startDate       DATE NOT NULL,
    endDate         DATE NOT NULL,
    staffId         INTEGER NOT NULL,
    FOREIGN KEY (reservationId) REFERENCES reservation(reservationId),
    FOREIGN KEY (roomId)        REFERENCES room(roomId),
    FOREIGN KEY (staffId)       REFERENCES staff(staffId)
);

CREATE TABLE event (
    eventId             INTEGER PRIMARY KEY,
    customerId          INTEGER NOT NULL,        
    organizationId      INTEGER,
    eventName           TEXT NOT NULL,
    startTime           DATETIME NOT NULL,
    endTime             DATETIME NOT NULL,
    expectedAttendance  INTEGER NOT NULL,
    expectedGuest       INTEGER NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (organizationId) REFERENCES organization(organizationId)
);

CREATE TABLE event_meeting_room_assignment (
    eventId         INTEGER,
    meetingRoomId   INTEGER,
    PRIMARY KEY (eventId, meetingRoomId),
    FOREIGN KEY (eventId) REFERENCES event(eventId),
    FOREIGN KEY (meetingRoomId) REFERENCES meeting_room_detail(meetingRoomId)
);

CREATE TABLE customer_event_attendance (
    customerId  INTEGER,
    eventId     INTEGER,
    PRIMARY KEY (customerId, eventId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (eventId)    REFERENCES event(eventId)
);

CREATE TABLE event_meeting_room_cost (
    eventCostId         INTEGER PRIMARY KEY,
    eventId             INTEGER NOT NULL,
    meetingRoomQuantity INTEGER,
    usageSlot           TEXT,          
    hasGrantedUsage     INTEGER DEFAULT 0,
    discountStatus      TEXT,
    FOREIGN KEY (eventId) REFERENCES event(eventId)
);


CREATE TABLE service_charge (
    chargeId        INTEGER PRIMARY KEY,
    discountRate    REAL DEFAULT 0.0,
    status          TEXT,             
    chargeAmount    REAL NOT NULL,
    serviceId       INTEGER,
    FOREIGN KEY (serviceId) REFERENCES service(serviceId)
);

CREATE TABLE billing (
    billingId   INTEGER PRIMARY KEY,     
    customerId  INTEGER NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customer(customerId)
);

CREATE TABLE transmittal_transaction (
    transactionId       INTEGER PRIMARY KEY,
    chargeId            INTEGER,
    billingId           INTEGER,
    chargedDate         DATETIME,
    sleepingRoomCostId  INTEGER,
    eventCostId         INTEGER,
    FOREIGN KEY (chargeId)           REFERENCES service_charge(chargeId),
    FOREIGN KEY (billingId)          REFERENCES billing(billingId),
    FOREIGN KEY (sleepingRoomCostId) REFERENCES sleeping_room_cost(sleepingRoomCostId),
    FOREIGN KEY (eventCostId)        REFERENCES event_meeting_room_cost(eventCostId)
);

